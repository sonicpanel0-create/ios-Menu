// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct ABP_LobbyRefitCloseUp_C_GetCameraWorldLocation_Params
{
	struct FVector                                     cameraWorldLocation;                                       
};

 
struct ABP_LobbyRefitCloseUp_C_UserConstructionScript_Params
{
};

 
struct ABP_LobbyRefitCloseUp_C_ChanTransformWithBlend_Params
{
	struct FTransform                                  B;                                                         
};

 
struct ABP_LobbyRefitCloseUp_C_ExecuteUbergraph_BP_LobbyRefitCloseUp_Params
{
	int                                                EntryPoint;                                                
};

}


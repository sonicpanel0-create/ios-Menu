// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_VehicleRefitPatternTable_type
{
	int                                                IconScale2_0_46572E4071F9B3293BE305FF087656B2;             
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     IconPath2_1_024EF7804CE8216627C3CAFF038879F2;              
	int                                                IconScale1_2_46562E0071F9B3283BE305F8087656B1;             
	unsigned char                                      UnknownData01[0x4];                                        
	struct FString                                     IconPath1_3_024DF7404CE8216527C3CAFC038879F1;              
	int                                                ID_4_3B4768C07AEB475737EB9B560A7BEF14;                     
	unsigned char                                      UnknownData02[0x4];                                        
	struct FString                                     IconOffset_5_59F5A18037D665B02424026A0AB3EDF4;             
	struct FString                                     PatternBPPath_6_4B5944C06FBA413D7EB727A808597AD8;          
};

}


// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_PSKillSprint_LevelConfig_type
{
	int                                                ID_0_1DEA3FC01212630D093D7D080EF82FB4;                     
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     LevelIcon_1_6E845CC06CD115293919B1730343FE7E;              
	struct FString                                     Name_2_2907FCC041155AAB00A4FCCF08302AC5;                   
};

}


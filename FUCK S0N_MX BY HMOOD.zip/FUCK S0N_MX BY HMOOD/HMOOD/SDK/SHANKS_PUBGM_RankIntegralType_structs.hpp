// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
enum class ERankIntegralType : uint8_t
{
	RankIntegralType__NewEnumerator2 = 0,
	RankIntegralType__NewEnumerator3 = 1,
	RankIntegralType__NewEnumerator1 = 2,
	RankIntegralType__NewEnumerator0 = 3,
	RankIntegralType__NewEnumerator5 = 4,
	RankIntegralType__NewEnumerator6 = 5,
	RankIntegralType__NewEnumerator7 = 6,
	RankIntegralType__NewEnumerator8 = 7,
	RankIntegralType__NewEnumerator9 = 8,
	RankIntegralType__NewEnumerator10 = 9,
	RankIntegralType__RankIntegralType_MAX = 10
};



}


// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_UGCTemplateTypeConfig_type
{
	int                                                ID_0_1F136D802CFD98C40CEF7AC2020DA834;                     
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     Name_2_5F2B6A804FFE0E4C063F4B4B0DA9A635;                   
	int                                                Sort_3_15DC744042BB9645063904A10DA98494;                   
	int                                                Type_4_35F7D2C0492ABF0901E794790DA96265;                   
	bool                                               IsSceneTypeDifferent_6_348D43005127CF18516D5CA00E5E3DE4;   
	unsigned char                                      UnknownData01[0x7];                                        
	TArray<int>                                        SceneTypeList_a_7_00E9E5405079A2F70D110C0806C09F81;        
};

}


// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct UClusterReplicationSubsystem_SetAutoClearCache_Params
{
	bool                                               Val;                                                       
};

 
struct UClusterReplicationSubsystem_SetAutoCache_Params
{
	bool                                               Val;                                                       
};

 
struct UClusterReplicationSubsystem_RemoveAllCachedObjectData_Params
{
};

}


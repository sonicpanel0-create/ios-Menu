// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct UUIParticle_StopEmit_Params
{
};

 
struct UUIParticle_Stop_Params
{
};

 
struct UUIParticle_SetPlayParticle_Params
{
	bool                                               InPlayParticle;                                            
};

 
struct UUIParticle_Play_Params
{
};

 
struct UUIParticleEmitter_StopEmit_Params
{
};

 
struct UUIParticleEmitter_Stop_Params
{
};

 
struct UUIParticleEmitter_SetPlayParticle_Params
{
	bool                                               InPlayParticle;                                            
};

 
struct UUIParticleEmitter_Play_Params
{
};

}


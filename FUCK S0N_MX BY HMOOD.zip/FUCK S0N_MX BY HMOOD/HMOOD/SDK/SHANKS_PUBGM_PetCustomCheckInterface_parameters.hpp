// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct UPetCustomCheckInterface_C_NotAllowAppear_Params
{
	bool                                               Out;                                                       
};

}


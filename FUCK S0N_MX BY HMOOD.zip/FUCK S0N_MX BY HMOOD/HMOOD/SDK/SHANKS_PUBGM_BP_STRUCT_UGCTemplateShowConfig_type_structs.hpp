// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_UGCTemplateShowConfig_type
{
	struct FString                                     BgImage_0_189C2D00164662963F4D6F91069B3D35;                
	struct FString                                     DefaultCreateName_1_5B2E70805B23EE1C645B1E730A767705;      
	struct FString                                     Desc_2_43B929C0338CB4C9041C4F1900AE4EC3;                   
	int                                                ID_3_2E18ED400F169C795350734B0250AE34;                     
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     Name_4_7D992A402421CD2F0403302300AFA665;                   
	int                                                Sort_5_344A340016DF55280477C35300AF84C4;                   
	int                                                TemplateID_6_61321C403A461AF10BBB42360787E3C4;             
	int                                                Type_7_546592801D4E7DEC0471CECF00AF6235;                   
	unsigned char                                      UnknownData01[0x4];                                        
	struct FString                                     Version_8_743EC38049EF3B2C5178439502EC96AE;                
	int                                                BlueHoleBan_9_7A90B240317D418D0C09B93205C586EE;            
	int                                                SceneType_10_7ED26E003A4B14940615FFDD0F4057D5;             
	int                                                TagID_11_68F2144023DC63FD2B2847D60AF45ED4;                 
	int                                                AllBan_12_5E9BB480468AFE3219A41D4F0EA158DE;                
	int                                                BlockyLua_13_1B72AB8053AF15343F26E1CA00A844A1;             
	unsigned char                                      UnknownData02[0x4];                                        
	TArray<struct FString>                             IntroductoryDiagram_as_14_2A8EE9803B2CF82072C9746A01F027A3; 
	struct FString                                     MapSize_15_42DA98405121DE4B646C122E0DA0ABF5;               
	struct FString                                     OriginalAuthorUID_21_5CF32C80384C6980500E11B20C36DBC4;     
	int                                                PlayTime_17_2B413340326DD3E72D34D05F00DE01A5;              
	unsigned char                                      UnknownData03[0x4];                                        
	TArray<int>                                        TemplateMods_a_18_6A1DEDC05F4F3C595DF86F36043240B1;        
	struct FString                                     DownlineTime_22_19771DC077396019704F195B021E3BB5;          
	struct FString                                     LaunchTime_23_4F3F448025F66A762DFD882B043266C5;            
	bool                                               IsPCTemplate_24_1A714CC018785FF37BA46AF605AD30A5;          
};

}


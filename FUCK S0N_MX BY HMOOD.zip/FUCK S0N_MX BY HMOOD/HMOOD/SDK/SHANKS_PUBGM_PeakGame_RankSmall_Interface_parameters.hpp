// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct UPeakGame_RankSmall_Interface_C_SetRankText_Params
{
	struct FSlateColor                                 Color;                                                     
	struct FSlateColor                                 ShadowColor;                                               
	struct FSlateFontInfo                              FontInfo;                                                  
};

}


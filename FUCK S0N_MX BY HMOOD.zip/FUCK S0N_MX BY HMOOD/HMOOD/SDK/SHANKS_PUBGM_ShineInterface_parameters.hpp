// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct UShineInterface_C_ShowNormal_Params
{
};

 
struct UShineInterface_C_ShowShine_Params
{
};

}


// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_DiySuitColorConfig_type
{
	int                                                ItemID_1_15B6748029F10AF4167429B5070FACB4;                 
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     BPUrl_2_1E617EC03A4F456D2C223D0106670E5C;                  
	int                                                Cost_3_63AB73C07271FCFF75FDA1880D66A384;                   
	int                                                ID_4_0CD2D0C023DDAD912AEEEF92052D66D4;                     
	struct FString                                     ColorName_9_56C1CD807D19C79E1E3D3EDE01B12E25;              
	TArray<int>                                        MaskColor1_a_11_14512C805333B5405D0FD0FD032BE651;          
	TArray<int>                                        MaskColor2_a_12_6E69ECC05EBDA3E75D0FD734032BE551;          
	TArray<int>                                        MaskColor3_a_13_4882AD006A47928E5D0F3AA4032BEC51;          
	float                                              GrayScale_f_15_0D6CFD80123EC6A658D3D8300FFAF166;           
	unsigned char                                      UnknownData01[0x4];                                        
	TArray<int>                                        UIShowColor_a_16_100C6D00219953BA2ABB948401FA2891;         
};

}


// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_LobbySceneSkinTable_type
{
	struct FString                                     SkinStreamLevelName_0_3781FCC026A707C5085B0B8D0763C135;    
	int                                                SkinID_1_11FAE6C0633AFB313233DCF907356724;                 
	int                                                SkinStyleKey1_6_3E24BE404C85800940BF19450D807901;          
	int                                                SkinStyleKey2_7_3E25BE804C85800A40BF19440D807902;          
	int                                                SkinStyleKey3_8_3E26BEC04C85800B40BF19470D807903;          
	int                                                SkinStyleKey4_9_3E27BF004C85800C40BF19460D807904;          
	int                                                SkinStyleKey5_10_3E28BF404C85800D40BF19410D807905;         
	int                                                SkinStyleKey6_11_3E29BF804C85800E40BF19400D807906;         
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     hallMaskPic1_12_547A3CC06D45501D04D1A1C60CD4F9A1;          
	struct FString                                     hallMaskPic2_13_547B3D006D45501E04D1A1C50CD4F9A2;          
	struct FString                                     hallMaskPic3_14_547C3D406D45501F04D1A1C40CD4F9A3;          
	int                                                SkinStreamLevelSequence_15_44C54AC019B77F5B7D933C0F0B8CE785; 
	unsigned char                                      UnknownData01[0x4];                                        
	struct FString                                     SpecialSeqBeginTime_16_125215C07E3A716F7117DA240D5E3895;   
	struct FString                                     SpecialSeqEndTime_17_644262405142B7BD616639190C5913A5;     
	int                                                SpecialSkinStreamLevelSequence_18_541FFB001C76779866F9357405F3B135; 
	unsigned char                                      UnknownData02[0x4];                                        
	struct FString                                     LightLevel_19_71F51A40227C33E15E7904D90A8557CC;            
	struct FString                                     MaskPic2_20_76CC14C07BD2E74701CF9A0B0C4598E2;              
	struct FString                                     MaskPic3_21_76CD15007BD2E74801CF9A0A0C4598E3;              
};

}


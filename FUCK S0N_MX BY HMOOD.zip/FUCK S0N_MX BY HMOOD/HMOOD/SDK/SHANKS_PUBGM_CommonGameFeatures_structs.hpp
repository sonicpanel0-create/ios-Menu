// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FRepControlGroupData
{
	TMap<int64_t, int>                                 RepControlMap;                                             
};

}


// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_VehicleRefitInfo_type
{
	int                                                cost_num1_0_206D9D404A460C770DD906380BC58481;              
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     unlock_part_list_1_154E4640205F8CA9261052710E193D64;       
	int                                                cost_num2_5_206E9D804A460C780DD9063F0BC58482;              
	int                                                cost_id2_6_69AB5CC07C73718975D5265F08BC42F2;               
	int                                                vehicle_group_id_8_28A4BD0014BDAA3A35B5E24106F2D5E4;       
	int                                                level_9_406ABD00274B124A3D84959D01EC2D9C;                  
	int                                                cost_id1_11_69AA5C807C73718875D5265808BC42F1;              
	int                                                vehicle_id_14_12DD9A006C12A260363420170D9E9004;            
	int                                                VehicleShapeID_15_1C46A68016CA3E7862FCD8770C15F554;        
	unsigned char                                      UnknownData01[0x4];                                        
	struct FString                                     DefaultStyleList_16_42E513804A54486A3C87203A06970FC4;      
	int                                                CameraMapID_17_008BD40017FB573E1D5C69DF09B42634;           
	unsigned char                                      UnknownData02[0x4];                                        
	struct FString                                     des_18_2CE9E60030AFF29C7BC43AC30121D423;                   
	int                                                levelShowedInStore_19_0F3E688048D05E406085DB75090EB705;    
	unsigned char                                      UnknownData03[0x4];                                        
	struct FString                                     levelIcon_20_3B181F40595EF03B0759382D0DA1167E;             
	int                                                levelShowRefit_21_62A703C06E7AA2A73D47FB960412BC34;        
	unsigned char                                      UnknownData04[0x4];                                        
	struct FString                                     big_icon_22_6C9A25804E63836E6E62E43101E7E53E;              
	struct FString                                     StaticMeshPath_23_08D3F7804FBB3CE866105B0D080582D8;        
	int                                                effectId_24_1B2A1D802F1E8EC807DD4D3302D9B5A4;              
	int                                                Weight_25_0F8E51004042186C48082A5E0E35EFE4;                
};

}


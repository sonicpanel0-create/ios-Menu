// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_MixItemCommonItemShowCfg_type
{
	struct FString                                     ChildName_0_274D1840452014476EC205370AB8C1A5;              
	int                                                ZOrder_1_69C994804B18E5A67F256F560911E332;                 
};

}


// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
enum class EPeakGame_RankIntegralType : uint8_t
{
	PeakGame_RankIntegralType__NewEnumerator2 = 0,
	PeakGame_RankIntegralType__NewEnumerator3 = 1,
	PeakGame_RankIntegralType__NewEnumerator1 = 2,
	PeakGame_RankIntegralType__NewEnumerator0 = 3,
	PeakGame_RankIntegralType__NewEnumerator5 = 4,
	PeakGame_RankIntegralType__NewEnumerator6 = 5,
	PeakGame_RankIntegralType__NewEnumerator7 = 6,
	PeakGame_RankIntegralType__NewEnumerator8 = 7,
	PeakGame_RankIntegralType__NewEnumerator9 = 8,
	PeakGame_RankIntegralType__PeakGame_MAX = 9
};



}


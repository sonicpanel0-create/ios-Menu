// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_WeaponScopeMaterial_type
{
	struct FString                                     ScopeGroupID_0_289E4F406E35B6A1337959050F04DD14;           
	struct FString                                     ScopeMaterial_1_4BEFD48030177D8A6925FD700F8D124C;          
	struct FString                                     ScopeMaterialSocket_2_63700EC07064DCC960E067A00E289394;    
	struct FString                                     ScopeMaterialColor_3_1DC014403E6A0BAB129284A605F29442;     
};

}


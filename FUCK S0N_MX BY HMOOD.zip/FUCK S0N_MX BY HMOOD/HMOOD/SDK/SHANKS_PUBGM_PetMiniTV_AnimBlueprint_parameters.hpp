// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct UPetMiniTV_AnimBlueprint_C_EvaluateGraphExposedInputs_ExecuteUbergraph_PetMiniTV_AnimBlueprint_AnimGraphNode_TransitionResult_1DDC764C421D165D8327F2911CC4991C_Params
{
};

 
struct UPetMiniTV_AnimBlueprint_C_EvaluateGraphExposedInputs_ExecuteUbergraph_PetMiniTV_AnimBlueprint_AnimGraphNode_BlendSpacePlayer_2306A39C4D7CE8A70EECEBB37BFCCB93_Params
{
};

 
struct UPetMiniTV_AnimBlueprint_C_EvaluateGraphExposedInputs_ExecuteUbergraph_PetMiniTV_AnimBlueprint_AnimGraphNode_TransitionResult_C17DD9FF4071D328B547BEA232EEB16F_Params
{
};

 
struct UPetMiniTV_AnimBlueprint_C_EvaluateGraphExposedInputs_ExecuteUbergraph_PetMiniTV_AnimBlueprint_AnimGraphNode_SequencePlayer_009041B3462D8CF2D4A201865DD876D2_Params
{
};

 
struct UPetMiniTV_AnimBlueprint_C_EvaluateGraphExposedInputs_ExecuteUbergraph_PetMiniTV_AnimBlueprint_AnimGraphNode_TransitionResult_CA199F1E416BF993AF4C84B8BAFD41C4_Params
{
};

 
struct UPetMiniTV_AnimBlueprint_C_EvaluateGraphExposedInputs_ExecuteUbergraph_PetMiniTV_AnimBlueprint_AnimGraphNode_SequencePlayer_BE8933BC4CCCEB2BCB7183AD234DBB67_Params
{
};

 
struct UPetMiniTV_AnimBlueprint_C_EvaluateGraphExposedInputs_ExecuteUbergraph_PetMiniTV_AnimBlueprint_AnimGraphNode_SequencePlayer_A30E6183458B0B3F2595A8A2ED7F8D0C_Params
{
};

 
struct UPetMiniTV_AnimBlueprint_C_EvaluateGraphExposedInputs_ExecuteUbergraph_PetMiniTV_AnimBlueprint_AnimGraphNode_BlendListByBool_2DE059B04DF7111204D21EBAFE22CE81_Params
{
};

 
struct UPetMiniTV_AnimBlueprint_C_EvaluateGraphExposedInputs_ExecuteUbergraph_PetMiniTV_AnimBlueprint_AnimGraphNode_BlendListByBool_823FBE9B475C16E23156C4A71722896F_Params
{
};

 
struct UPetMiniTV_AnimBlueprint_C_EvaluateGraphExposedInputs_ExecuteUbergraph_PetMiniTV_AnimBlueprint_AnimGraphNode_BlendListByBool_3D1960524214E1A6816BEF84FE55493B_Params
{
};

 
struct UPetMiniTV_AnimBlueprint_C_EvaluateGraphExposedInputs_ExecuteUbergraph_PetMiniTV_AnimBlueprint_AnimGraphNode_TransitionResult_00BBBF784BC9B749FFA330BFA402AEBD_Params
{
};

 
struct UPetMiniTV_AnimBlueprint_C_EvaluateGraphExposedInputs_ExecuteUbergraph_PetMiniTV_AnimBlueprint_AnimGraphNode_TransitionResult_50BBE809472C38EAB593E3834784AEDB_Params
{
};

 
struct UPetMiniTV_AnimBlueprint_C_AnimNotify_OnEnterIdle_Params
{
};

 
struct UPetMiniTV_AnimBlueprint_C_AnimNotify_OnLeftIdle_Params
{
};

 
struct UPetMiniTV_AnimBlueprint_C_AnimNotify_OnEnterSleepStart_Params
{
};

 
struct UPetMiniTV_AnimBlueprint_C_AnimNotify_OnLeftSleepStart_Params
{
};

 
struct UPetMiniTV_AnimBlueprint_C_EvaluateGraphExposedInputs_ExecuteUbergraph_PetMiniTV_AnimBlueprint_AnimGraphNode_TransitionResult_8184F36049B1B9154763B98AE881E97B_Params
{
};

 
struct UPetMiniTV_AnimBlueprint_C_ExecuteUbergraph_PetMiniTV_AnimBlueprint_Params
{
	int                                                EntryPoint;                                                
};

}


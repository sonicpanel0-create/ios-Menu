// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_DrinkCompoundConfig_type
{
	int                                                awardID_0_2BBEB1403F5A9B0B0EB1D00709609964;                
	int                                                awardNum_1_37D1DA0026A0923C7757AA8B0609AE2D;               
	int                                                descID_2_1FD235403A90703F024A7AEA0BB716C4;                 
	int                                                ID_3_2F902D8037E77FA46237D6880B8119C4;                     
	int                                                isMayCarry_4_2AB2AB40581603397B72EE3809C59429;             
	int                                                JpKrAwardID_5_49A847000D2541FE5295535A097982A4;            
	int                                                JpKrAwardNum_6_2ECC8FC045A856D735DAF8570798322D;           
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     Name_7_3AE82A806F13962C42B917EB011A5DB5;                   
	struct FString                                     solt_8_7F0FFAC007CB390F4285A58D011A9FB4;                   
	int                                                EmoteID_9_4C84EC007C583218352536360B9EB844;                
	unsigned char                                      UnknownData01[0x4];                                        
	struct FString                                     PhizExplain_10_2575C54064E510CF536AC4300D724F0E;           
	struct FString                                     EmoteVoiceName_11_60ECC6803A15389C4AA097EC0673F2D5;        
};

}


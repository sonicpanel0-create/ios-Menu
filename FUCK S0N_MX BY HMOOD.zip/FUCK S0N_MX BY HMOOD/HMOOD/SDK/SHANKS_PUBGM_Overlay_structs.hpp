// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FOverlayItem
{
	struct FTimespan                                   StartTime;                                                 
	struct FTimespan                                   EndTime;                                                   
	struct FString                                     Text;                                                      
	struct FVector2D                                   Position;                                                  
};

}


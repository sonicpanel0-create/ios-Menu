// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct UPetEntityComponent_BP_C_GetAttachInfoFromTable_Params
{
	struct FFixPetAttachInfo*                          Info;                                                      
	struct FPetAttachInfo                              ReturnValue;                                               
};

}


// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_RecommendDelete_type
{
	int                                                ID_0_086B8400728145E4295143780ED1FFD4;                     
	int                                                nActDay_1_5ED509C054F4D2FD43415E1602979569;                
	int                                                nCondition1_2_49EB9240540319512D0C230506E88D41;            
	int                                                nCondition2_3_49EC9280540319522D0C230406E88D42;            
	int                                                nCycleDay_4_63BF7FC049CBBEC95915A934029D78C9;              
	int                                                nDeleteAll_5_10C1974050B4C62B6C0F63D60334B45C;             
	int                                                nMapTimeLimte_6_304CA6407A10DBB56A9AA1EC0057C185;          
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     sDeleteData_7_38EE70C019CC767F190FECBD036EEF91;            
};

}


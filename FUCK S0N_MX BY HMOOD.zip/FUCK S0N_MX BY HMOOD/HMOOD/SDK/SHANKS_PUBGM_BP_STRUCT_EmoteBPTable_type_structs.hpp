// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_EmoteBPTable_type
{
	struct FString                                     Path_0_247605C000C1809320361CC70BC26958;                   
	struct FString                                     CName_1_20BFF38058E1993E3181765E0C385985;                  
	int                                                ID_2_6D1FE5C03D4B9B6365DA363A01FBC3D4;                     
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     LobbyPath_3_17CBE3C0186812E1377BBB6D07222BE8;              
	struct FString                                     LobbyEmoteAdapt_4_6274998039C4B44E5D4A1AFE0DB5A954;        
	struct FString                                     BattleLowPath_5_4F3B89400282AC756B607A450BF84618;          
	struct FString                                     PathHigh_6_050CC5C0133BD80B2E9B638909572DB8;               
	struct FString                                     EmoteCollisionBox_7_694DF6406325C17B04D93B540C600578;      
	struct FString                                     EmoteCollisionCenterOffset_8_1BBE3E0042190C225D66B4B007074504; 
};

}


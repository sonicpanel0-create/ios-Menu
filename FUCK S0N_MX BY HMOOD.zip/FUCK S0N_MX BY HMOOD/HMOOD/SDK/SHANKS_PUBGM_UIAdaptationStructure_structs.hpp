// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FUIAdaptationStructure
{
	struct FString                                     DeviceName_2_A8CF6E1F40D8116DD8A17D97AD6515ED;             
	float                                              LeftOffset_5_61C5916847A6DB0845C03799C935F0CD;             
	float                                              RightOffset_7_338321234218040563FB88B423EA8023;            
	float                                              TopOffset_9_68D32A004301A63A4ABF20B129DBC8DE;              
	float                                              BottomOffset_11_0C31E5BC4AA9CD8E9DBA4A9D456E101E;          
};

}


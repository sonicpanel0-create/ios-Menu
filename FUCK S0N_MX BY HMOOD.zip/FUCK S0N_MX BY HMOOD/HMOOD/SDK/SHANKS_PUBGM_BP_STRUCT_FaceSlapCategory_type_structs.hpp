// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_FaceSlapCategory_type
{
	int                                                FaceSlapType_0_0BDDFD001A64B8E27C01DDFA05084AE5;           
	int                                                ID_1_11BF7800670E71866DCA45D80A10E794;                     
	int                                                LobbyType_2_0D659B4062E7FD4B6DADBAAB09904795;              
	int                                                ModuleID_3_664A71802DF41BD66D1460AC0FACC154;               
	bool                                               NeedActivity_4_3E95A700177FEB4A6A99CA1C02B17829;           
	bool                                               NeedLimit_5_3D64538023E55E885D25F9840A9C8414;              
	unsigned char                                      UnknownData00[0x2];                                        
	int                                                Sort_6_0E6DFEC02091CEB32C2A964000E6EC84;                   
	struct FString                                     TriggerEventID_7_4CF2AD805D28C1924E7851490E276244;         
	struct FString                                     TriggerEventType_8_3C9712C06AD110A9019AAFC407633E45;       
	int                                                PackageLimit_10_02AF3F803F1FE8445CD340B40BCF7394;          
};

}


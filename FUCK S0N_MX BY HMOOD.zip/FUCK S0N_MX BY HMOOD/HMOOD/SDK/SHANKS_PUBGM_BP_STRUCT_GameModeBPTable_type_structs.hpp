// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_GameModeBPTable_type
{
	int                                                ID_0_5A5311F84AF5AD63F284598DF413D62D;                     
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     CName_1_120D6DB74537DE28D87E4BAD2052E558;                  
	struct FString                                     Path_2_D808EF6946A66B7E51F6318FC7CCE098;                   
};

}


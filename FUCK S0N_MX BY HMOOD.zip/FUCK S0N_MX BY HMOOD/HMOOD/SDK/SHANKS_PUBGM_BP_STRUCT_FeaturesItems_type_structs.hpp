// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_FeaturesItems_type
{
	int                                                ID_4_70B6D9000F7C4138010820A90EFCE7B4;                     
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     Features_6_6384C58014BE35983FAD42C605772F63;               
	struct FString                                     SFeatures_7_4235FA4078CACDE3584EEB4C0445A9E3;              
	int                                                NeedTlog_8_776EDA4045D035A97259BD5F05455B77;               
};

}


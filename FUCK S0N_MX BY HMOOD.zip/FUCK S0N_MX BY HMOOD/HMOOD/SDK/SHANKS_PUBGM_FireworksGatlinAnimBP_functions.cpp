// HMOOD__TG@i_8_f
 

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
 

void UFireworksGatlinAnimBP_C::EvaluateGraphExposedInputs_ExecuteUbergraph_FireworksGatlinAnimBP_AnimGraphNode_ModifyBone_103CE9D54941589FEC28F8A82AC2C65D()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function FireworksGatlinAnimBP.FireworksGatlinAnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_FireworksGatlinAnimBP_AnimGraphNode_ModifyBone_103CE9D54941589FEC28F8A82AC2C65D");

	UFireworksGatlinAnimBP_C_EvaluateGraphExposedInputs_ExecuteUbergraph_FireworksGatlinAnimBP_AnimGraphNode_ModifyBone_103CE9D54941589FEC28F8A82AC2C65D_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 

void UFireworksGatlinAnimBP_C::EvaluateGraphExposedInputs_ExecuteUbergraph_FireworksGatlinAnimBP_AnimGraphNode_ModifyBone_7594665B453619945A04B9A45B53D8E5()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function FireworksGatlinAnimBP.FireworksGatlinAnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_FireworksGatlinAnimBP_AnimGraphNode_ModifyBone_7594665B453619945A04B9A45B53D8E5");

	UFireworksGatlinAnimBP_C_EvaluateGraphExposedInputs_ExecuteUbergraph_FireworksGatlinAnimBP_AnimGraphNode_ModifyBone_7594665B453619945A04B9A45B53D8E5_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 

void UFireworksGatlinAnimBP_C::EvaluateGraphExposedInputs_ExecuteUbergraph_FireworksGatlinAnimBP_AnimGraphNode_ModifyBone_76F3E93741D1EE0080E835BF9141B6D5()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function FireworksGatlinAnimBP.FireworksGatlinAnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_FireworksGatlinAnimBP_AnimGraphNode_ModifyBone_76F3E93741D1EE0080E835BF9141B6D5");

	UFireworksGatlinAnimBP_C_EvaluateGraphExposedInputs_ExecuteUbergraph_FireworksGatlinAnimBP_AnimGraphNode_ModifyBone_76F3E93741D1EE0080E835BF9141B6D5_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 
 
 

void UFireworksGatlinAnimBP_C::ExecuteUbergraph_FireworksGatlinAnimBP(int EntryPoint)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function FireworksGatlinAnimBP.FireworksGatlinAnimBP_C.ExecuteUbergraph_FireworksGatlinAnimBP");

	UFireworksGatlinAnimBP_C_ExecuteUbergraph_FireworksGatlinAnimBP_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


}


// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_3DIconBPTable_type
{
	struct FString                                     CName_0_197F95006C7D41D02E19833803105905;                  
	int                                                ID_1_6249C74062AE6BD53F17F69101F33054;                     
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     Path_2_064E67406FC200F32023304A0331E958;                   
};

}


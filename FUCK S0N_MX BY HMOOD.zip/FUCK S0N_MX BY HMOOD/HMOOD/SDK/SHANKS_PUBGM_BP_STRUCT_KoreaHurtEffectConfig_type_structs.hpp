// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_KoreaHurtEffectConfig_type
{
	struct FString                                     ColorA_0_463EE38073B0E8305CFF6EAE0F8DA261;                 
	struct FString                                     ColorB_1_463FE3C073B0E8315CFF6EAF0F8DA262;                 
	struct FString                                     ColorG_2_4644E50073B0E8365CFF6EA80F8DA267;                 
	struct FString                                     ColorR_3_464FE7C073B0E8415CFF6E9F0F8DA272;                 
	struct FString                                     ID_4_7F7536C04FE524AB454A945D09B40F34;                     
	struct FString                                     ResPath_5_0DED414024DEE0F1299E986806532848;                
};

}


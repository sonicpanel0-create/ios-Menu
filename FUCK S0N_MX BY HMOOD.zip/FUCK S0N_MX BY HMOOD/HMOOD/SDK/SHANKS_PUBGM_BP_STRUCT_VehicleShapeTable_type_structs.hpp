// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_VehicleShapeTable_type
{
	struct FString                                     MeshBasePath_0_417CD1001B80DC1E44CCF1BC0A899508;           
	struct FString                                     BPPath_1_04FA93804ECCC4B06DEB74AB015A0988;                 
	int                                                ID_2_63908F0075AF39C00FB6A5F00F6121F4;                     
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     AnimBPPath_3_12EBB4C05FB48819333454CC00540308;             
};

}


// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_ItemSoundTable_type
{
	struct FString                                     EquipSound_0_068B68C066212493052EBF3305D63E14;             
	struct FString                                     DropSound_1_4DD7CD003E11476C25039DA50902AA34;              
	int                                                ID_2_42F748C040D81BA3690F7C020EF58C44;                     
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     PickUpSound_3_0B99FAC07345086D4963B6D504877D14;            
	struct FString                                     DropBank_4_1D8769C022E35E311709B3FF07910C6B;               
	struct FString                                     EquipBank_5_30BCE58001E2251E07D41C7C055C432B;              
	struct FString                                     UnEquipBank_6_4FF4964008C1F90F14F8C45904D7459B;            
	struct FString                                     UnEquipSound_7_0376B980772F43423C77A2D80D665704;           
	struct FString                                     PickUpBank_8_3C7477801367726A5EFE3B0D0549773B;             
};

}


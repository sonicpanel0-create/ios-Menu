// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FSTR_CameraSetting
{
	float                                              TargetArmLength_30_2007ABB34694949F7A9AC4BB2C7AE57D;       
	float                                              LagSpeed_34_CBFA29604D40F5BC431D969F9216FCF7;              
	struct FVector                                     SocketOffset_26_FD34F6424351327A3F447882FEBC198D;          
};

}


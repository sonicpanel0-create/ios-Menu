// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FTeamPlayerColorStruct
{
	int                                                PlayerIndex_2_B5DB2BC241DE79BAF475BE89C208CBB8;            
	struct FLinearColor                                PlayerColor_5_2248AF6545C3D12AA0C1F18AF3A9AC40;            
};

}


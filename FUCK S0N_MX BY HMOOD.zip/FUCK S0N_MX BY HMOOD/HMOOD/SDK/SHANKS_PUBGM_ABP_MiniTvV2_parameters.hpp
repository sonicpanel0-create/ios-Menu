// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct UABP_MiniTvV2_C_SetFloat_Params
{
	bool                                               NewParam;                                                  
};

 
struct UABP_MiniTvV2_C_SetDragType_Params
{
	int                                                dragtype;                                                  
};

 
struct UABP_MiniTvV2_C_SetSpeed_Params
{
	float                                              Speed;                                                     
};

 
struct UABP_MiniTvV2_C_SetWalk_Params
{
	bool                                               Walk;                                                      
};

 
struct UABP_MiniTvV2_C_SetDrag_Params
{
	bool                                               Drag;                                                      
};

 
struct UABP_MiniTvV2_C_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_MiniTvV2_AnimGraphNode_TransitionResult_19841E7D4C46CCAFB40201BDF9E5D873_Params
{
};

 
struct UABP_MiniTvV2_C_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_MiniTvV2_AnimGraphNode_TransitionResult_CC54C0DE4BA6E9A5DF3DA1879D014F03_Params
{
};

 
struct UABP_MiniTvV2_C_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_MiniTvV2_AnimGraphNode_TransitionResult_F58490434CB11F9A31650F99F1D1DF1F_Params
{
};

 
struct UABP_MiniTvV2_C_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_MiniTvV2_AnimGraphNode_TransitionResult_B0F82852421A66DECFE9EFB6EF4F6C75_Params
{
};

 
struct UABP_MiniTvV2_C_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_MiniTvV2_AnimGraphNode_BlendSpacePlayer_0EF67A5049A5CD62888251AFDE418FDA_Params
{
};

 
struct UABP_MiniTvV2_C_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_MiniTvV2_AnimGraphNode_BlendListByInt_8A9E8E3A46E8EA408644E3A04A6F8F0B_Params
{
};

 
struct UABP_MiniTvV2_C_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_MiniTvV2_AnimGraphNode_TransitionResult_21378E764DBB7DD292494BAB7888D1F1_Params
{
};

 
struct UABP_MiniTvV2_C_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_MiniTvV2_AnimGraphNode_BlendListByInt_90B7F6A24016EED663E049A0B83BE627_Params
{
};

 
struct UABP_MiniTvV2_C_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_MiniTvV2_AnimGraphNode_TransitionResult_9452BEDA44C9873D1F58EFB6EE16DCB6_Params
{
};

 
struct UABP_MiniTvV2_C_ExecuteUbergraph_ABP_MiniTvV2_Params
{
	int                                                EntryPoint;                                                
};

 
struct UABP_MiniTvV2_C_OnWalkEnd__DelegateSignature_Params
{
};

}


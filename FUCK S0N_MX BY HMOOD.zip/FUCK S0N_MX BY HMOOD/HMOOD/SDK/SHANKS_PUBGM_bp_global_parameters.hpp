// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct Abp_global_C_EventShowPlatWXStartup_NoFetch_Params
{
};

 
struct Abp_global_C_EventShowPlatWXStartup_Params
{
};

 
struct Abp_global_C_EventShowPlatQQStartup_NoFetch_Params
{
};

 
struct Abp_global_C_EventShowPlatQQStartup_Params
{
};

 
struct Abp_global_C_EventShowPlatIconTips_NoFetch_Params
{
};

 
struct Abp_global_C_EventShowPlatIconTips_Params
{
};

 
struct Abp_global_C_EventSetInfo_Push_NoFetch_Params
{
};

 
struct Abp_global_C_EventSetInfo_Push_Params
{
};

 
struct Abp_global_C_EventSendClickGemReport_NoFetch_Params
{
};

 
struct Abp_global_C_EventSendClickGemReport_Params
{
};

 
struct Abp_global_C_EventSendBAReport_NoFetch_Params
{
};

 
struct Abp_global_C_EventSendBAReport_Params
{
};

 
struct Abp_global_C_EventGlobalUseItem_NoFetch_Params
{
};

 
struct Abp_global_C_EventGlobalUseItem_Params
{
};

 
struct Abp_global_C_EventGlobalCloseItemTips_NoFetch_Params
{
};

 
struct Abp_global_C_EventGlobalCloseItemTips_Params
{
};

 
struct Abp_global_C_EventFetchNationSwitch_NoFetch_Params
{
};

 
struct Abp_global_C_EventFetchNationSwitch_Params
{
};

 
struct Abp_global_C_EventFetchInfo_NoFetch_Params
{
};

 
struct Abp_global_C_EventFetchInfo_Params
{
};

 
struct Abp_global_C_EventComMsgBoxSluaClickUrl_NoFetch_Params
{
};

 
struct Abp_global_C_EventComMsgBoxSluaClickUrl_Params
{
};

 
struct Abp_global_C_EventClickLobbyEventGemReport_NoFetch_Params
{
};

 
struct Abp_global_C_EventClickLobbyEventGemReport_Params
{
};

 
struct Abp_global_C_EventCheckIfMenuOpen_NoFetch_Params
{
};

 
struct Abp_global_C_EventCheckIfMenuOpen_Params
{
};

 
struct Abp_global_C_EventAndroidQuitGame_NoFetch_Params
{
};

 
struct Abp_global_C_EventAndroidQuitGame_Params
{
};

 
struct Abp_global_C_UserConstructionScript_Params
{
};

}


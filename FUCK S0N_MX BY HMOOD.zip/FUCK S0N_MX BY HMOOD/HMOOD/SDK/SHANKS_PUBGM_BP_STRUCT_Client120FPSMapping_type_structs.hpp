// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_Client120FPSMapping_type
{
	int                                                ID_0_52B7B2807016C5CE506644460AB41F74;                     
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     ModelNames_1_399D08807AD6F26037FD5FE60034ECE3;             
	struct FString                                     RecommendFPS_2_1A6DF000025FF64C17E158AF0DA5B963;           
	struct FString                                     MaxFPSByQuality_3_6AD77C001F8707C23E3E50050F416079;        
};

}


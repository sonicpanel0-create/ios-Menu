// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct ULobby_Main_Money_UIBP_C_Construct_Params
{
};

 
struct ULobby_Main_Money_UIBP_C_ExecuteUbergraph_Lobby_Main_Money_UIBP_Params
{
	int                                                EntryPoint;                                                
};

}


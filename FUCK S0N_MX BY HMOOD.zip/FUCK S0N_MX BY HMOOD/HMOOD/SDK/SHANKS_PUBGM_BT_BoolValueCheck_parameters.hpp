// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct UBT_BoolValueCheck_C_PerformConditionCheck_Params
{
	class AActor**                                     OwnerActor;                                                
	bool                                               ReturnValue;                                               
};

 
struct UBT_BoolValueCheck_C_ExecuteUbergraph_BT_BoolValueCheck_Params
{
	int                                                EntryPoint;                                                
};

}


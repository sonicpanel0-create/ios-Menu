// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_VNHitEffectConfig_type
{
	struct FString                                     ID_17_1855A3C018BE7CE74928E35406902744;                    
	struct FString                                     Layer1ColorA_1_4996FC000E081E3E2ECB32D60D3C5A11;           
	struct FString                                     Layer1ColorB_2_4997FC400E081E3F2ECB32C90D3C5A12;           
	struct FString                                     Layer1ColorG_3_499CFD800E081E442ECB32CC0D3C5A17;           
	struct FString                                     Layer1ColorR_4_49A800400E081E4F2ECB33390D3C5A02;           
	struct FString                                     Layer2ColorA_5_089F3C405B10804508668D7F0E3C5A11;           
	struct FString                                     Layer2ColorB_6_08A03C805B10804608668D700E3C5A12;           
	struct FString                                     Layer2ColorG_7_08A53DC05B10804B08668D750E3C5A17;           
	struct FString                                     Layer2ColorR_8_08B040805B10805608668D600E3C5A02;           
	struct FString                                     Layer3ColorA_9_47A77C802818E24C47025FA50F3C5A11;           
	struct FString                                     Layer3ColorB_10_47A87CC02818E24D47025FA40F3C5A12;          
	struct FString                                     Layer3ColorG_11_47AD7E002818E25247025FAF0F3C5A17;          
	struct FString                                     Layer3ColorR_12_47B880C02818E25D47025FB40F3C5A02;          
	struct FString                                     Layer4ColorA_13_06AFBCC0752144532F29F712003C5A11;          
	struct FString                                     Layer4ColorB_14_06B0BD00752144542F29F713003C5A12;          
	struct FString                                     Layer4ColorG_15_06B5BE40752144592F29F6EC003C5A17;          
	struct FString                                     Layer4ColorR_16_06C0C100752144642F29F6E3003C5A02;          
	struct FString                                     SettingColorA_18_5304E80078FE8A3257CFE4B00B489841;         
	struct FString                                     SettingColorB_19_5305E84078FE8A3357CFE4B10B489842;         
	struct FString                                     SettingColorG_20_530AE98078FE8A3857CFE48E0B489847;         
	struct FString                                     SettingColorR_21_5315EC4078FE8A4357CFE4810B489852;         
	struct FString                                     ResPath_22_064D2E40633E42F55CDC31C801A16AC8;               
};

}


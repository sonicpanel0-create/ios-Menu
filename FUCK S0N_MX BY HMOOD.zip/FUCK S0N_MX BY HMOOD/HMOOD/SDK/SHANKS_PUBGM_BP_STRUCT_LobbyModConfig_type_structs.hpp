// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_LobbyModConfig_type
{
	TArray<struct FName>                               DependMod_an_0_4C94888029AA0E8C57B2966F0A00F7CE;           
	struct FString                                     ModKey_1_42F073401109DD2D6F192178016CAB39;                 
	struct FString                                     ResPath_2_0F3BAEC069FE39572CA9B8750E59C7B8;                
};

}


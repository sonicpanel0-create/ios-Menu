// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_TransSupportConfig_GLOBAL_type
{
	int                                                languageID_0_1D9BF4801A0CAF180454007A0E59BFB4;             
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     displayName_1_7B233E0045C681C6393652C80C537045;            
	struct FString                                     abbreviation_2_7270DDC045E369B7531E4D2001C2187E;           
	bool                                               isSupported_3_297FC8C037F3503F7D952DE609923274;            
	unsigned char                                      UnknownData01[0x7];                                        
	struct FString                                     languageCode_4_0C60B000517E13D413D2E28809C00BF5;           
};

}


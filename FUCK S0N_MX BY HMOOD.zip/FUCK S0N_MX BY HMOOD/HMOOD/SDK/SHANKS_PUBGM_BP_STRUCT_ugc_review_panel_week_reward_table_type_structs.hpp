// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_ugc_review_panel_week_reward_table_type
{
	int                                                award_item_cnt1_0_35DE5F40383CA31D19A835F900DCC341;        
	int                                                award_item_cnt2_1_35DF5F80383CA31E19A835F800DCC342;        
	int                                                award_item_id1_2_2807814076CF347D03CAD10D030DCD11;         
	int                                                award_item_id2_3_2808818076CF347E03CAD10C030DCD12;         
	int                                                finish_val_4_44082B80034AA0EE5D9C28A3068A47EC;             
	int                                                season_id_5_3879B0001036F52266944E8D05057214;              
	struct FString                                     task_desc_6_48F8AF006C085B5A013C242C0674F843;              
	int                                                task_desc_local_id_7_452F94801A7446E83FAEDD380A14F684;     
	int                                                task_id_8_5F45BA80707B67907DB0D8E504D674A4;                
	int                                                valid_hours1_9_7CB777007143C6F2772156FE00D520F1;           
	int                                                valid_hours2_10_7CB877407143C6F3772156FF00D520F2;          
	struct FString                                     award_item_icon1_11_65099840275233872EAEC7210DCE0711;      
	struct FString                                     award_item_icon2_12_650A9880275233882EAEC7260DCE0712;      
	int                                                task_type_13_59A517C02FDB258D0135A3430677F4B5;             
};

}


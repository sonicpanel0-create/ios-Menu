// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_DiySuitNumConfig_type
{
	struct FString                                     IconUrl_0_43EF28C044399FBD0B85F19509DDF67C;                
	struct FString                                     ID_1_353BBD004B023124772EBE53059CAFB4;                     
};

}


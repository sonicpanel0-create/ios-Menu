// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_WeaponAvatarBattleEffect_type
{
	int                                                ID_0_5DEDE54072F9770F24CC59220C975D44;                     
	int                                                Opacity_4_248EF8405566ED7775F694880FAEF559;                
	struct FString                                     BgPath_5_57B6EF804218D14414997B550D10FFF8;                 
	int                                                IsFixColor_6_3314BA80204E2CFC58913B8B0798DA02;             
	int                                                B_7_16D8F2805F7B045E78F002D109C975D2;                      
	int                                                R_8_16E8F6805F7B046E78F002C109C975C2;                      
	int                                                G_9_16DDF3C05F7B046378F002DA09C975D7;                      
	struct FString                                     EffectPath_11_17EB988040F0D4DA01E4BC790CF448F8;            
	int                                                EmotionID_12_1C80DC003AB2B942245E5E330FDB96D4;             
	int                                                isForbideWeaponIdleAnim_13_3C37E3000333ADA8045CF16700283ABD; 
	struct FString                                     AnimationName_14_1E1DCA4031775317410DA0CE01E60B45;         
	float                                              WeaponEmoteDuration_f_15_4B2BFDC0050D1CF7600E5A800F283086; 
	int                                                WeaponEmoteID_16_7E0FFE407BE0454123B764C700578824;         
	struct FString                                     KillCounterColor_17_12C59CC045ED27E13703D2110BB22402;      
	struct FString                                     KillCounterEffectColor_18_327610007126A2C264362738013BF0B2; 
};

}


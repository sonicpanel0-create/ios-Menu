// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_LobbyCameraAnim_type
{
	struct FString                                     CameraAnimAssetPath_0_7C698DC035F0C6450219563901395A88;    
	struct FString                                     ID_1_2611FA407D8728976A1458B60E3E2D44;                     
};

}


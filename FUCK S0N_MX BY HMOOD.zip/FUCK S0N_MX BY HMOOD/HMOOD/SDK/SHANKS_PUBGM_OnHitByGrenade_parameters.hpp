// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct UOnHitByGrenade_C_OnHitByCake_Params
{
};

}


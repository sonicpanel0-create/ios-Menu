// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_PSKillSprint_LevelSkillConfig_type
{
	int                                                ID_0_6D3D3F803CC229E64BB2E09B0E5F7D64;                     
	int                                                LevelID_1_3EEF1D800918B520672E6ABF09295734;                
	int                                                RoleID_2_001AA400504402FE32C03E630C4C76A4;                 
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     SkillDesc_3_3DA33BC05555C9F522764D450BE76F63;              
	struct FString                                     SkillIcon_4_2B985E407F9165D32274D9130BE73BAE;              
	int                                                SkillName_8_77833C4008D80CBB227291640BE885C5;              
	unsigned char                                      UnknownData01[0x4];                                        
	struct FString                                     SkillTipPic1_6_740C5A8009203C9A1B046BAF073AD101;           
	struct FString                                     SkillTipPic2_7_740D5AC009203C9B1B046BAE073AD102;           
};

}


// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct UChangePetState_C_ReceiveExecuteAI_Params
{
	class AAIController**                              OwnerController;                                           
	class APawn**                                      ControlledPawn;                                            
};

 
struct UChangePetState_C_ExecuteUbergraph_ChangePetState_Params
{
	int                                                EntryPoint;                                                
};

}


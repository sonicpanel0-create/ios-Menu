// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_VehicleRefitColorTable_type
{
	int                                                ID_0_7607F1003C307130785E051708091744;                     
	int                                                Gray_1_23C2528073E753A86CAE45C709177089;                   
	struct FString                                     Color3_2_133F1A40217781872E65F412071E3F43;                 
	struct FString                                     Color2_3_133E1A00217781862E65F413071E3F42;                 
	struct FString                                     Color1_4_133D19C0217781852E65F410071E3F41;                 
	struct FString                                     ColorBPPath_5_507BD54027F0DEF913818BAA07048B58;            
};

}


// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
class UBasePetABP_C : public USTExtraPetAnimInstance
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                            
	struct FAnimNode_Slot                              AnimGraphNode_Slot_F8D526254A85A7BD5DE9D1AE4A14B263;       
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_D446CD9D4A7FFAC8981A65A8F1F45569; 
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_B89A0BC6474DBAE52C326BAA23D88647; 
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_F6B2889A4DE765AE4D2D889584A98B18; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_D3C858314E1DA79D3BCF90B5A415C27D; 
	struct FAnimNode_StateMachine                      AnimGraphNode_StateMachine_F9CDD1514C4A20F836475FBD2BB36DCE; 
	struct FAnimNode_SaveCachedPose                    AnimGraphNode_SaveCachedPose_1BB357F64C76570843AE5B84C2F7CEB2; 
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_6813BADF4F7EEFC3B3DBD08B1D8DADC6; 
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_CE743A514D5E4D277DBD2AB141552806; 
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_12236F064CD7AE7B7333CD83216CC82F; 
	struct FAnimNode_SaveCachedPose                    AnimGraphNode_SaveCachedPose_70CC06554CE62E26B9B290830BAB759E; 
	struct FAnimNode_SaveCachedPose                    AnimGraphNode_SaveCachedPose_C3F6ACAD4099926E95FBCA9EA23545DC; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_E21B1F9345DC795DABC8D1A9DC21356B; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_88086AE94D458BF339DDF49C030BAC8D; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_6D41291441BF31781A90EB8AA878F524; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_C7923B5546659CBBB05F978557E7984B; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_1F1217244C743912C63308A2C19461F3; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_45C4DF654B7ABA309EAE7B91D9A59978; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_D5F4D4094E2A63878ED042A083D69675; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_235007F846A892725CD6AAAC8E0894F8; 
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_4E1B6E3C4295EDAD81F9A2BA3ABAF7B1; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_884772EB4E9B0F6FFBCA8491829B68BA; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_C030F17142ACE73779C04D8C52F73E4A; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_DB913D964FFC2560A0F5A086FA82355A; 
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_A37FE82C4EA834252D40C28F6A1FCD50; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_D8F7DC594A7D125E69D5B8BE2B0AB059; 
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_4186564B4D382D04BA589A87C3B35D6E; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_1AC949FC454200AE969E5A81393827F3; 
	struct FAnimNode_StateMachine                      AnimGraphNode_StateMachine_C40199904EDBAB995784A981C137D7FF; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_026886AB43567BC65904908A6B0212DB; 
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_2AA8C592476168C6320361962A2F6A2A; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_65BC131A4608DACA84EADB9677488FE2; 
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_1CF96EC64FCAB2CDD495BE863F050AF9; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_3B1F1823464A230A961F18ACBED76AB5; 
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_CAABD589489563EA761DB79D58B83DB1; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_71742F2B4652E176857298B636317F5B; 
	struct FAnimNode_StateMachine                      AnimGraphNode_StateMachine_C91D704D47A762EB4FEEF8A07C3D62DA; 
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_AC03404E455535C444C431AF45F64262; 
	struct FAnimNode_Root                              AnimGraphNode_Root_D982C72548DF7C2CB7D2D0A8197E4659;       

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("AnimBlueprintGeneratedClass BasePetABP.BasePetABP_C");
		return pStaticClass;
	}


	void EvaluateGraphExposedInputs_ExecuteUbergraph_BasePetABP_AnimGraphNode_SequencePlayer_4E1B6E3C4295EDAD81F9A2BA3ABAF7B1();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_BasePetABP_AnimGraphNode_TransitionResult_45C4DF654B7ABA309EAE7B91D9A59978();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_BasePetABP_AnimGraphNode_TransitionResult_C030F17142ACE73779C04D8C52F73E4A();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_BasePetABP_AnimGraphNode_TransitionResult_DB913D964FFC2560A0F5A086FA82355A();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_BasePetABP_AnimGraphNode_SequencePlayer_A37FE82C4EA834252D40C28F6A1FCD50();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_BasePetABP_AnimGraphNode_TransitionResult_1F1217244C743912C63308A2C19461F3();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_BasePetABP_AnimGraphNode_SequencePlayer_4186564B4D382D04BA589A87C3B35D6E();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_BasePetABP_AnimGraphNode_TransitionResult_C7923B5546659CBBB05F978557E7984B();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_BasePetABP_AnimGraphNode_SequencePlayer_2AA8C592476168C6320361962A2F6A2A();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_BasePetABP_AnimGraphNode_SequencePlayer_1CF96EC64FCAB2CDD495BE863F050AF9();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_BasePetABP_AnimGraphNode_TransitionResult_88086AE94D458BF339DDF49C030BAC8D();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_BasePetABP_AnimGraphNode_SequencePlayer_CAABD589489563EA761DB79D58B83DB1();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_BasePetABP_AnimGraphNode_TransitionResult_E21B1F9345DC795DABC8D1A9DC21356B();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_BasePetABP_AnimGraphNode_BlendListByBool_6813BADF4F7EEFC3B3DBD08B1D8DADC6();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_BasePetABP_AnimGraphNode_SequencePlayer_F6B2889A4DE765AE4D2D889584A98B18();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_BasePetABP_AnimGraphNode_BlendListByBool_D446CD9D4A7FFAC8981A65A8F1F45569();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_BasePetABP_AnimGraphNode_TransitionResult_235007F846A892725CD6AAAC8E0894F8();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_BasePetABP_AnimGraphNode_TransitionResult_D5F4D4094E2A63878ED042A083D69675();
	void ExecuteUbergraph_BasePetABP(int EntryPoint);
};


}


// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_WeaponSkinMapping_type
{
	struct FString                                     OutputDesc_0_4C755C4055DE81011AC086EE07D9D3D3;             
	int                                                SkinID_1_6AF5A0C03E8D665F2B8E33D5019212C4;                 
	int                                                WeaponID_2_1D11360041F2AB4A2B54AC9608775314;               
	struct FString                                     URL_3_276895001829BC3265405AC70F011B5C;                    
	struct FString                                     iconURL_4_1C201F405280621B7F9C0B550EBB3B4C;                
	int                                                OriginalWeaponID_5_764A434007CD302F016BC8A906745804;       
};

}

